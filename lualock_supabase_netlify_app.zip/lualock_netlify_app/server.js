require('dotenv').config();
const createApp = require('./src/createApp');

const app = createApp();
const port = process.env.PORT || 3000;

app.listen(port, () => {
  console.log(`LuaLock running on http://localhost:${port}`);
});
