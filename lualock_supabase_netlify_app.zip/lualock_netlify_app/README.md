# LuaLock Dashboard

Dark LuaLock dashboard starter with:

- Signup and login
- Password hashing with bcryptjs
- Supabase Postgres database through `pg`
- Postgres-backed sessions through `connect-pg-simple`
- Protected dashboard pages
- Projects, scripts, access keys, HWID reset placeholder, audit logs, and settings pages
- Netlify Functions wrapper

## Local setup

```bash
npm install
cp .env.example .env
```

Create a free Supabase project, copy your Postgres connection string, and put it in `.env` as `DATABASE_URL`.

For serverless hosting like Netlify, use the Supabase **Transaction pooler** connection string when possible:

```env
DATABASE_URL="postgresql://postgres.PROJECT_REF:YOUR_PASSWORD@aws-0-REGION.pooler.supabase.com:6543/postgres?sslmode=require"
SESSION_SECRET="make-a-long-random-secret"
```

Run locally:

```bash
npm run dev
```

Open:

```text
http://localhost:3000
```

## Optional admin seed

Set these in `.env` first:

```env
ADMIN_EMAIL="owner@example.com"
ADMIN_USERNAME="owner"
ADMIN_PASSWORD="change-me-before-use"
```

Then run:

```bash
npm run seed:admin
```

## Reset database

This deletes all LuaLock app tables. Only do this on a test database.

```bash
ALLOW_DB_RESET=yes npm run reset:db
```

## Netlify

Deploy this repo to Netlify. Add these environment variables in Netlify:

- `DATABASE_URL`
- `SESSION_SECRET`
- optional `PG_POOL_MAX=3`

The app runs through `netlify/functions/api.js` and redirects all routes through that function.
