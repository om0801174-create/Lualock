require('dotenv').config();
const { resetDb, pool } = require('../src/db');

async function main() {
  if (process.env.ALLOW_DB_RESET !== 'yes') {
    throw new Error('Refusing to reset. Set ALLOW_DB_RESET=yes in .env if you really want to delete all app tables.');
  }
  await resetDb();
  console.log('Database reset complete.');
}

main()
  .catch((err) => {
    console.error(err.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    await pool.end();
  });
