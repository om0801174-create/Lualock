require('dotenv').config();
const { createUser, initDb, pool } = require('../src/db');

async function main() {
  await initDb();
  const email = process.env.ADMIN_EMAIL;
  const username = process.env.ADMIN_USERNAME || 'owner';
  const password = process.env.ADMIN_PASSWORD;

  if (!email || !password) {
    throw new Error('Set ADMIN_EMAIL and ADMIN_PASSWORD in .env before running npm run seed:admin.');
  }

  const user = await createUser({ email, username, password, role: 'owner', plan: 'pro' });
  console.log(`Created admin user: ${user.email}`);
}

main()
  .catch((err) => {
    console.error(err.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    await pool.end();
  });
