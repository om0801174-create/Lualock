const serverless = require('serverless-http');
const createApp = require('../../src/createApp');

const app = createApp();

exports.handler = serverless(app);
