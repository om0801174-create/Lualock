# Netlify + Supabase setup for LuaLock

This version no longer uses temporary SQLite. It uses Supabase Postgres so accounts and dashboard data survive redeploys.

## 1. Create Supabase database

1. Go to Supabase.
2. Create a new project.
3. Wait for the project to finish provisioning.
4. Click **Connect** in the Supabase dashboard.
5. Copy the **Transaction pooler** URI if available. It is better for serverless functions.
6. Replace the password placeholder with your real Supabase database password.

Example format:

```env
DATABASE_URL="postgresql://postgres.PROJECT_REF:YOUR_PASSWORD@aws-0-REGION.pooler.supabase.com:6543/postgres?sslmode=require"
```

## 2. Add Netlify environment variables

In Netlify:

Site configuration → Environment variables → Add variables

Add:

```env
DATABASE_URL=your_supabase_connection_string
SESSION_SECRET=make-a-long-random-secret
PG_POOL_MAX=3
```

Do not commit real secrets to GitHub.

## 3. Deploy settings

Netlify should read `netlify.toml` automatically.

Build command:

```bash
echo Building LuaLock for Netlify
```

Publish directory:

```text
public
```

## 4. First run

The app creates the required Postgres tables automatically on first request:

- users
- projects
- scripts
- access_keys
- hwid_resets
- audit_logs
- user_sessions

Go to `/signup` and create your first account.

## Notes

- If login redirects keep failing, check `SESSION_SECRET` and `DATABASE_URL`.
- If Supabase goes idle/free project pauses, wake the project in the Supabase dashboard.
- Do not use the database reset script on a real user database.
