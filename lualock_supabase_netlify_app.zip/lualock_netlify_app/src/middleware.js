const { findUserById } = require('./db');

async function attachUser(req, res, next) {
  try {
    res.locals.flash = req.session.flash || null;
    delete req.session.flash;
    if (req.session.userId) {
      req.user = await findUserById(req.session.userId);
    }
    next();
  } catch (err) {
    next(err);
  }
}

function requireGuest(req, res, next) {
  if (req.user) return res.redirect('/dashboard');
  next();
}

function requireAuth(req, res, next) {
  if (!req.user) {
    req.session.flash = { type: 'error', message: 'Sign in to access the dashboard.' };
    return res.redirect('/login');
  }
  next();
}

function flash(req, type, message) {
  req.session.flash = { type, message };
}

function asyncRoute(handler) {
  return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
}

module.exports = { attachUser, requireGuest, requireAuth, flash, asyncRoute };
