const bcrypt = require('bcryptjs');
const { nanoid } = require('nanoid');
const { Pool } = require('pg');

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  console.warn('DATABASE_URL is not set. Add your Supabase Postgres connection string in Netlify environment variables.');
}

const pool = new Pool({
  connectionString,
  ssl: process.env.PGSSLMODE === 'disable' ? false : { rejectUnauthorized: false },
  max: Number(process.env.PG_POOL_MAX || 3),
  idleTimeoutMillis: 10000,
  connectionTimeoutMillis: 10000
});

let initPromise = null;

async function query(text, params = []) {
  if (!connectionString) {
    throw new Error('DATABASE_URL is missing. Add your Supabase Postgres connection string to Netlify environment variables.');
  }
  return pool.query(text, params);
}

async function initDb() {
  if (!initPromise) {
    initPromise = (async () => {
      await query(`
        CREATE TABLE IF NOT EXISTS users (
          id TEXT PRIMARY KEY,
          email TEXT NOT NULL UNIQUE,
          username TEXT NOT NULL,
          password_hash TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'owner',
          plan TEXT NOT NULL DEFAULT 'starter',
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
          last_login_at TIMESTAMPTZ
        );

        CREATE TABLE IF NOT EXISTS projects (
          id TEXT PRIMARY KEY,
          owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          slug TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'active',
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS scripts (
          id TEXT PRIMARY KEY,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          version TEXT NOT NULL DEFAULT 'v1.0.0',
          status TEXT NOT NULL DEFAULT 'draft',
          delivery_mode TEXT NOT NULL DEFAULT 'server',
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS access_keys (
          id TEXT PRIMARY KEY,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          script_id TEXT REFERENCES scripts(id) ON DELETE SET NULL,
          label TEXT NOT NULL,
          key_value TEXT NOT NULL UNIQUE,
          status TEXT NOT NULL DEFAULT 'active',
          hwid TEXT,
          expires_at DATE,
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
          last_used_at TIMESTAMPTZ
        );

        CREATE TABLE IF NOT EXISTS hwid_resets (
          id TEXT PRIMARY KEY,
          access_key_id TEXT NOT NULL REFERENCES access_keys(id) ON DELETE CASCADE,
          old_hwid TEXT,
          requested_hwid TEXT,
          reason TEXT,
          status TEXT NOT NULL DEFAULT 'pending',
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
          reviewed_at TIMESTAMPTZ
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
          id TEXT PRIMARY KEY,
          user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
          action TEXT NOT NULL,
          target_type TEXT NOT NULL,
          target_id TEXT,
          message TEXT NOT NULL,
          ip TEXT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );

        CREATE INDEX IF NOT EXISTS idx_projects_owner ON projects(owner_id);
        CREATE INDEX IF NOT EXISTS idx_scripts_project ON scripts(project_id);
        CREATE INDEX IF NOT EXISTS idx_keys_project ON access_keys(project_id);
        CREATE INDEX IF NOT EXISTS idx_logs_user ON audit_logs(user_id);
      `);
    })();
  }
  return initPromise;
}

function slugify(input) {
  return String(input || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || `project-${nanoid(6)}`;
}

function publicUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    email: row.email,
    username: row.username,
    role: row.role,
    plan: row.plan,
    created_at: row.created_at,
    last_login_at: row.last_login_at
  };
}

async function createUser({ email, username, password, role = 'owner', plan = 'starter' }) {
  await initDb();
  const normalizedEmail = String(email || '').trim().toLowerCase();
  if (!normalizedEmail.includes('@')) throw new Error('Enter a valid email address.');
  if (!username || username.trim().length < 2) throw new Error('Username must be at least 2 characters.');
  if (!password || password.length < 8) throw new Error('Password must be at least 8 characters.');

  const exists = await query('SELECT id FROM users WHERE email = $1', [normalizedEmail]);
  if (exists.rows[0]) throw new Error('An account with this email already exists.');

  const id = nanoid();
  const password_hash = bcrypt.hashSync(password, 12);
  await query(
    'INSERT INTO users (id, email, username, password_hash, role, plan) VALUES ($1, $2, $3, $4, $5, $6)',
    [id, normalizedEmail, username.trim(), password_hash, role, plan]
  );

  await createStarterData(id);
  await logAction({ userId: id, action: 'user.signup', targetType: 'user', targetId: id, message: 'Account created.' });
  const user = await query('SELECT * FROM users WHERE id = $1', [id]);
  return publicUser(user.rows[0]);
}

async function findUserByEmail(email) {
  await initDb();
  const result = await query('SELECT * FROM users WHERE email = $1', [String(email || '').trim().toLowerCase()]);
  return result.rows[0] || null;
}

async function findUserById(id) {
  await initDb();
  const result = await query('SELECT * FROM users WHERE id = $1', [id]);
  return publicUser(result.rows[0]);
}

async function verifyLogin(email, password, ip) {
  await initDb();
  const user = await findUserByEmail(email);
  if (!user) throw new Error('Email or password is wrong.');
  const ok = bcrypt.compareSync(password || '', user.password_hash);
  if (!ok) throw new Error('Email or password is wrong.');
  await query('UPDATE users SET last_login_at = NOW(), updated_at = NOW() WHERE id = $1', [user.id]);
  await logAction({ userId: user.id, action: 'auth.login', targetType: 'user', targetId: user.id, message: 'Signed in.', ip });
  return publicUser({ ...user, last_login_at: new Date().toISOString() });
}

async function createStarterData(userId) {
  const projectId = nanoid();
  const scriptId = nanoid();
  const keyId = nanoid();
  await query('INSERT INTO projects (id, owner_id, name, slug) VALUES ($1, $2, $3, $4)', [projectId, userId, 'Midnight Hub', 'midnight-hub']);
  await query('INSERT INTO scripts (id, project_id, name, version, status) VALUES ($1, $2, $3, $4, $5)', [scriptId, projectId, 'premium-loader', 'v1.0.0', 'live']);
  await query(
    'INSERT INTO access_keys (id, project_id, script_id, label, key_value, status) VALUES ($1, $2, $3, $4, $5, $6)',
    [keyId, projectId, scriptId, 'Demo buyer', `LL-${nanoid(4).toUpperCase()}-${nanoid(8).toUpperCase()}`, 'active']
  );
}

async function logAction({ userId = null, action, targetType, targetId = null, message, ip = null }) {
  await initDb();
  await query(
    'INSERT INTO audit_logs (id, user_id, action, target_type, target_id, message, ip) VALUES ($1, $2, $3, $4, $5, $6, $7)',
    [nanoid(), userId, action, targetType, targetId, message, ip]
  );
}

function countValue(row) {
  return Number(row?.count || 0);
}

async function getOverview(userId) {
  await initDb();
  const [projects, scripts, keys, resets] = await Promise.all([
    query('SELECT COUNT(*)::int AS count FROM projects WHERE owner_id = $1', [userId]),
    query(`
      SELECT COUNT(*)::int AS count FROM scripts s
      JOIN projects p ON p.id = s.project_id
      WHERE p.owner_id = $1
    `, [userId]),
    query(`
      SELECT COUNT(*)::int AS count FROM access_keys k
      JOIN projects p ON p.id = k.project_id
      WHERE p.owner_id = $1 AND k.status = 'active'
    `, [userId]),
    query(`
      SELECT COUNT(*)::int AS count FROM hwid_resets r
      JOIN access_keys k ON k.id = r.access_key_id
      JOIN projects p ON p.id = k.project_id
      WHERE p.owner_id = $1 AND r.status = 'pending'
    `, [userId])
  ]);
  return {
    projects: countValue(projects.rows[0]),
    scripts: countValue(scripts.rows[0]),
    keys: countValue(keys.rows[0]),
    resets: countValue(resets.rows[0])
  };
}

async function getProjects(userId) {
  await initDb();
  const result = await query(`
    SELECT p.*,
      (SELECT COUNT(*)::int FROM scripts s WHERE s.project_id = p.id) AS script_count,
      (SELECT COUNT(*)::int FROM access_keys k WHERE k.project_id = p.id) AS key_count
    FROM projects p
    WHERE p.owner_id = $1
    ORDER BY p.created_at DESC
  `, [userId]);
  return result.rows;
}

async function createProject(userId, name) {
  await initDb();
  const id = nanoid();
  const trimmed = String(name || '').trim();
  const slug = `${slugify(trimmed)}-${nanoid(4)}`;
  await query('INSERT INTO projects (id, owner_id, name, slug) VALUES ($1, $2, $3, $4)', [id, userId, trimmed, slug]);
  await logAction({ userId, action: 'project.create', targetType: 'project', targetId: id, message: `Created project ${trimmed}.` });
  return id;
}

async function getScripts(userId) {
  await initDb();
  const result = await query(`
    SELECT s.*, p.name AS project_name
    FROM scripts s
    JOIN projects p ON p.id = s.project_id
    WHERE p.owner_id = $1
    ORDER BY s.created_at DESC
  `, [userId]);
  return result.rows;
}

async function createScript(userId, { projectId, name, version }) {
  await initDb();
  const owns = await query('SELECT id FROM projects WHERE id = $1 AND owner_id = $2', [projectId, userId]);
  if (!owns.rows[0]) throw new Error('Project not found.');
  const id = nanoid();
  const trimmed = String(name || '').trim();
  await query(
    'INSERT INTO scripts (id, project_id, name, version, status) VALUES ($1, $2, $3, $4, $5)',
    [id, projectId, trimmed, String(version || '').trim() || 'v1.0.0', 'draft']
  );
  await logAction({ userId, action: 'script.create', targetType: 'script', targetId: id, message: `Added script ${trimmed}.` });
  return id;
}

async function getKeys(userId) {
  await initDb();
  const result = await query(`
    SELECT k.*, p.name AS project_name, s.name AS script_name
    FROM access_keys k
    JOIN projects p ON p.id = k.project_id
    LEFT JOIN scripts s ON s.id = k.script_id
    WHERE p.owner_id = $1
    ORDER BY k.created_at DESC
  `, [userId]);
  return result.rows;
}

async function createKey(userId, { projectId, scriptId = null, label, expiresAt = null }) {
  await initDb();
  const owns = await query('SELECT id FROM projects WHERE id = $1 AND owner_id = $2', [projectId, userId]);
  if (!owns.rows[0]) throw new Error('Project not found.');
  if (scriptId) {
    const script = await query(`
      SELECT s.id FROM scripts s JOIN projects p ON p.id = s.project_id
      WHERE s.id = $1 AND p.owner_id = $2
    `, [scriptId, userId]);
    if (!script.rows[0]) throw new Error('Script not found.');
  }
  const id = nanoid();
  const keyValue = `LL-${nanoid(4).toUpperCase()}-${nanoid(8).toUpperCase()}-${nanoid(4).toUpperCase()}`;
  const trimmedLabel = String(label || '').trim() || 'Untitled key';
  await query(
    'INSERT INTO access_keys (id, project_id, script_id, label, key_value, expires_at) VALUES ($1, $2, $3, $4, $5, $6)',
    [id, projectId, scriptId || null, trimmedLabel, keyValue, expiresAt || null]
  );
  await logAction({ userId, action: 'key.create', targetType: 'access_key', targetId: id, message: `Created key for ${trimmedLabel}.` });
  return keyValue;
}

async function revokeKey(userId, keyId) {
  await initDb();
  const key = await query(`
    SELECT k.id FROM access_keys k JOIN projects p ON p.id = k.project_id
    WHERE k.id = $1 AND p.owner_id = $2
  `, [keyId, userId]);
  if (!key.rows[0]) throw new Error('Key not found.');
  await query("UPDATE access_keys SET status = 'revoked' WHERE id = $1", [keyId]);
  await logAction({ userId, action: 'key.revoke', targetType: 'access_key', targetId: keyId, message: 'Revoked access key.' });
}

async function getLogs(userId, limit = 25) {
  await initDb();
  const result = await query(`
    SELECT * FROM audit_logs
    WHERE user_id = $1 OR user_id IS NULL
    ORDER BY created_at DESC
    LIMIT $2
  `, [userId, limit]);
  return result.rows;
}

async function resetDb() {
  await query(`
    DROP TABLE IF EXISTS audit_logs CASCADE;
    DROP TABLE IF EXISTS hwid_resets CASCADE;
    DROP TABLE IF EXISTS access_keys CASCADE;
    DROP TABLE IF EXISTS scripts CASCADE;
    DROP TABLE IF EXISTS projects CASCADE;
    DROP TABLE IF EXISTS users CASCADE;
  `);
  initPromise = null;
  await initDb();
}

module.exports = {
  pool,
  query,
  initDb,
  resetDb,
  createUser,
  verifyLogin,
  findUserById,
  getOverview,
  getProjects,
  createProject,
  getScripts,
  createScript,
  getKeys,
  createKey,
  revokeKey,
  getLogs,
  logAction
};
