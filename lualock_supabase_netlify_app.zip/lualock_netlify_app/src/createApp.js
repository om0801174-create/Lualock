const path = require('path');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const PgSession = require('connect-pg-simple')(session);
const { initDb, pool } = require('./db');
const { attachUser } = require('./middleware');
const publicRoutes = require('./routes/public');
const authRoutes = require('./routes/auth');
const dashboardRoutes = require('./routes/dashboard');

function createApp() {
  initDb().catch((error) => {
    console.error('Database initialization failed:', error.message);
  });

  const app = express();

  app.set('trust proxy', 1);
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        scriptSrc: ["'self'"],
        imgSrc: ["'self'", 'data:'],
        connectSrc: ["'self'"]
      }
    }
  }));
  app.use(express.urlencoded({ extended: false, limit: '50kb' }));
  app.use(express.json({ limit: '50kb' }));
  app.use(express.static(path.join(process.cwd(), 'public')));

  const sessionSecret = process.env.SESSION_SECRET || 'dev-secret-change-me';
  app.use(session({
    store: new PgSession({
      pool,
      tableName: 'user_sessions',
      createTableIfMissing: true
    }),
    name: 'lualock.sid',
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production' || Boolean(process.env.NETLIFY),
      maxAge: 1000 * 60 * 60 * 3
    }
  }));

  app.use(attachUser);
  app.use(publicRoutes);
  app.use(authRoutes);
  app.use(dashboardRoutes);

  app.use((req, res) => {
    res.status(404).send(`<!DOCTYPE html><html><head><title>Not found · LuaLock</title><link rel="stylesheet" href="/styles.css" /></head><body class="public-body"><main class="plain-page"><section><div class="pill"><span></span>404</div><h1>Page not found.</h1><p class="lead">That route does not exist.</p><a class="btn btn-primary" href="/dashboard">Go dashboard</a></section></main></body></html>`);
  });

  app.use((err, req, res, next) => {
    console.error(err);
    res.status(500).send(`<!DOCTYPE html><html><head><title>Server error · LuaLock</title><link rel="stylesheet" href="/styles.css" /></head><body class="public-body"><main class="plain-page"><section><div class="pill"><span></span>500</div><h1>Server error.</h1><p class="lead">${err.message || 'Something went wrong.'}</p><a class="btn btn-primary" href="/login">Back to login</a></section></main></body></html>`);
  });

  return app;
}

module.exports = createApp;
