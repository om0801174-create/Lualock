function esc(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

const logo = `
  <span class="logo" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M7 10V8a5 5 0 0 1 10 0v2"/><rect x="5" y="10" width="14" height="10" rx="3"/><path d="M12 14v2.5"/>
    </svg>
  </span>`;

function flashHtml(flash) {
  if (!flash) return '';
  return `<div class="toast ${flash.type === 'error' ? 'toast-error' : 'toast-ok'}">${esc(flash.message)}</div>`;
}

function publicLayout({ title, body, flash, user = null, current = '' }) {
  const loggedIn = Boolean(user);
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${esc(title)} · LuaLock</title>
  <link rel="stylesheet" href="/styles.css" />
</head>
<body class="public-body">
  <nav class="nav">
    <a class="brand" href="/">${logo}<strong>LuaLock</strong></a>
    <div class="nav-links">
      <a href="/features">Features</a>
      <a href="/pricing">Pricing</a>
      <a href="/docs">Docs</a>
      ${loggedIn ? `<a href="/dashboard">Dashboard</a>` : `<a href="/login">Login</a>`}
      ${loggedIn ? `<form method="post" action="/logout"><button class="btn btn-soft">Logout</button></form>` : `<a class="btn btn-primary" href="/signup">Sign up</a>`}
    </div>
  </nav>
  ${flashHtml(flash)}
  ${body}
  <script src="/app.js"></script>
</body>
</html>`;
}

function appLayout({ title, body, flash, user, current = 'dashboard' }) {
  const item = (href, label, key, icon) => `<a class="side-link ${current === key ? 'active' : ''}" href="${href}"><span>${icon}</span>${label}</a>`;
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${esc(title)} · LuaLock</title>
  <link rel="stylesheet" href="/styles.css" />
</head>
<body class="app-body">
  <aside class="sidebar">
    <a class="brand sidebar-brand" href="/dashboard">${logo}<strong>LuaLock</strong></a>
    <nav class="side-nav">
      ${item('/dashboard', 'Overview', 'dashboard', '◈')}
      ${item('/dashboard/projects', 'Projects', 'projects', '⬡')}
      ${item('/dashboard/scripts', 'Scripts', 'scripts', '◎')}
      ${item('/dashboard/keys', 'Keys', 'keys', '◇')}
      ${item('/dashboard/resets', 'HWID Resets', 'resets', '◌')}
      ${item('/dashboard/logs', 'Audit Logs', 'logs', '▣')}
      ${item('/dashboard/settings', 'Settings', 'settings', '⚙')}
    </nav>
    <div class="side-card">
      <span class="mini-label">Current plan</span>
      <strong>${esc(user.plan || 'starter')}</strong>
      <a href="/pricing">Upgrade plan →</a>
    </div>
  </aside>
  <div class="app-shell">
    <header class="topbar">
      <div>
        <span class="mini-label">Signed in as</span>
        <strong>${esc(user.email)}</strong>
      </div>
      <div class="top-actions">
        <a class="btn btn-soft" href="/">Site</a>
        <form method="post" action="/logout"><button class="btn btn-primary">Logout</button></form>
      </div>
    </header>
    ${flashHtml(flash)}
    ${body}
  </div>
  <script src="/app.js"></script>
</body>
</html>`;
}

function landing({ flash, user }) {
  const body = `
    <main class="landing">
      <section class="hero-grid">
        <div class="hero-copy reveal">
          <div class="pill"><span></span>Roblox Lua access control</div>
          <h1>Lock scripts. Issue keys. Run the dashboard.</h1>
          <p>LuaLock is a dark, KeyForge-style app starter with signup, login, Supabase Postgres, protected dashboard routes, projects, scripts, keys, logs, and cheaper pricing.</p>
          <div class="hero-actions">
            <a class="btn btn-primary" href="/signup">Create account</a>
            <a class="btn btn-soft" href="/login">Sign in</a>
          </div>
          <div class="mini-stats">
            <div><strong>$2</strong><span>first paid plan</span></div>
            <div><strong>Postgres</strong><span>Supabase database</span></div>
            <div><strong>bcrypt</strong><span>password hashing</span></div>
          </div>
        </div>
        <div class="terminal-card reveal">
          <div class="terminal-top"><span></span><span></span><span></span><small>dashboard/session</small></div>
          <pre><code>POST /login
email = owner@example.com
password = ********

bcrypt.compare(password, hash) → true
session.userId = user.id
redirect → /dashboard</code></pre>
          <div class="dashboard-preview">
            <div><b>Projects</b><strong>4</strong></div>
            <div><b>Scripts</b><strong>12</strong></div>
            <div><b>Keys</b><strong>750</strong></div>
          </div>
        </div>
      </section>
    </main>`;
  return publicLayout({ title: 'Home', body, flash, user });
}

function authPage({ type, flash }) {
  const isSignup = type === 'signup';
  const body = `
    <main class="auth-wrap">
      <section class="auth-card reveal">
        <a class="brand auth-brand" href="/">${logo}<strong>LuaLock</strong></a>
        <span class="mini-label">${isSignup ? 'Create your dashboard' : 'Welcome back'}</span>
        <h1>${isSignup ? 'Sign up' : 'Sign in'}</h1>
        <p>${isSignup ? 'Make an account and the app will create demo project data for your dashboard.' : 'Access your projects, scripts, keys, and audit logs.'}</p>
        <form method="post" action="/${isSignup ? 'signup' : 'login'}" class="stack-form">
          ${isSignup ? `<label>Username<input name="username" autocomplete="username" required minlength="2" placeholder="Oscar" /></label>` : ''}
          <label>Email<input name="email" type="email" autocomplete="email" required placeholder="you@example.com" /></label>
          <label>Password<input name="password" type="password" autocomplete="${isSignup ? 'new-password' : 'current-password'}" required minlength="8" placeholder="At least 8 characters" /></label>
          <label class="check"><input type="checkbox" name="remember" value="1" /> Keep this session active for 7 days</label>
          <button class="btn btn-primary" type="submit">${isSignup ? 'Create account' : 'Sign in'}</button>
        </form>
        <p class="auth-switch">${isSignup ? 'Already have an account?' : 'Don\'t have an account?'} <a href="/${isSignup ? 'login' : 'signup'}">${isSignup ? 'Sign in' : 'Sign up'}</a></p>
      </section>
    </main>`;
  return publicLayout({ title: isSignup ? 'Sign up' : 'Login', body, flash });
}

function featurePage({ flash, user }) {
  const body = `<main class="plain-page"><section><div class="pill"><span></span>Features</div><h1>Dashboard modules included.</h1><p class="lead">Projects, scripts, access keys, HWID reset queue, audit logs, user sessions, and auth routes.</p><div class="card-grid"><article><b>Projects</b><p>Group scripts by hub, private tool, or paid release.</p></article><article><b>Scripts</b><p>Track script names, versions, and delivery mode.</p></article><article><b>Keys</b><p>Create, list, and revoke access keys.</p></article><article><b>Logs</b><p>Track signups, logins, key creation, and admin actions.</p></article></div></section></main>`;
  return publicLayout({ title: 'Features', body, flash, user });
}

function pricingPage({ flash, user }) {
  const body = `<main class="plain-page"><section><div class="pill"><span></span>Pricing</div><h1>Cheaper LuaLock plans.</h1><p class="lead">Simple pricing for small Roblox script creators.</p><div class="price-grid"><article><h2>Starter</h2><strong>$0<small>/mo</small></strong><p>1 project, 2 scripts, 35 keys.</p><a class="btn btn-soft" href="/signup">Start</a></article><article class="featured"><h2>Builder</h2><strong>$2<small>/mo</small></strong><p>4 projects, 12 scripts, 750 keys.</p><a class="btn btn-primary" href="/signup">Choose Builder</a></article><article><h2>Pro</h2><strong>$6<small>/mo</small></strong><p>15 projects, 75 scripts, unlimited keys.</p><a class="btn btn-soft" href="/signup">Choose Pro</a></article></div></section></main>`;
  return publicLayout({ title: 'Pricing', body, flash, user });
}

function docsPage({ flash, user }) {
  const body = `<main class="plain-page"><section><div class="pill"><span></span>Docs</div><h1>Local setup.</h1><p class="lead">Create a Supabase project, add DATABASE_URL and SESSION_SECRET, then run the app locally or deploy to Netlify.</p><pre class="doc-code"><code>npm install
cp .env.example .env
# add your Supabase DATABASE_URL
npm run dev

# optional admin seed
npm run seed:admin</code></pre></section></main>`;
  return publicLayout({ title: 'Docs', body, flash, user });
}

function dashboardHome({ user, overview, projects, logs, flash }) {
  const projectRows = projects.map(p => `<tr><td>${esc(p.name)}</td><td>${esc(p.status)}</td><td>${p.script_count}</td><td>${p.key_count}</td><td>${esc(p.created_at)}</td></tr>`).join('') || `<tr><td colspan="5">No projects yet.</td></tr>`;
  const logRows = logs.map(l => `<li><b>${esc(l.action)}</b><span>${esc(l.message)}</span><small>${esc(l.created_at)}</small></li>`).join('') || '<li>No logs yet.</li>';
  const body = `<main class="dashboard-page"><div class="page-head"><div><span class="mini-label">Overview</span><h1>Dashboard</h1><p>Manage protected Lua scripts, keys, devices, and account activity.</p></div><a class="btn btn-primary" href="/dashboard/keys">Create key</a></div><section class="stat-grid"><article><span>Projects</span><strong>${overview.projects}</strong></article><article><span>Scripts</span><strong>${overview.scripts}</strong></article><article><span>Active keys</span><strong>${overview.keys}</strong></article><article><span>Pending resets</span><strong>${overview.resets}</strong></article></section><section class="two-col"><div class="panel"><div class="panel-head"><h2>Projects</h2><a href="/dashboard/projects">View all</a></div><table><thead><tr><th>Name</th><th>Status</th><th>Scripts</th><th>Keys</th><th>Created</th></tr></thead><tbody>${projectRows}</tbody></table></div><div class="panel"><div class="panel-head"><h2>Recent activity</h2><a href="/dashboard/logs">View logs</a></div><ul class="log-list">${logRows}</ul></div></section></main>`;
  return appLayout({ title: 'Dashboard', body, user, flash, current: 'dashboard' });
}

function projectsPage({ user, projects, flash }) {
  const rows = projects.map(p => `<tr><td>${esc(p.name)}</td><td>${esc(p.slug)}</td><td>${esc(p.status)}</td><td>${p.script_count}</td><td>${p.key_count}</td></tr>`).join('') || '<tr><td colspan="5">Create your first project.</td></tr>';
  const body = `<main class="dashboard-page"><div class="page-head"><div><span class="mini-label">Projects</span><h1>Projects</h1><p>Each project can hold scripts, access keys, and reset records.</p></div></div><section class="two-col narrow"><div class="panel"><div class="panel-head"><h2>New project</h2></div><form method="post" action="/dashboard/projects" class="stack-form"><label>Project name<input name="name" required placeholder="Midnight Hub" /></label><button class="btn btn-primary">Create project</button></form></div><div class="panel"><div class="panel-head"><h2>All projects</h2></div><table><thead><tr><th>Name</th><th>Slug</th><th>Status</th><th>Scripts</th><th>Keys</th></tr></thead><tbody>${rows}</tbody></table></div></section></main>`;
  return appLayout({ title: 'Projects', body, user, flash, current: 'projects' });
}

function scriptsPage({ user, projects, scripts, flash }) {
  const options = projects.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
  const rows = scripts.map(s => `<tr><td>${esc(s.name)}</td><td>${esc(s.project_name)}</td><td>${esc(s.version)}</td><td>${esc(s.status)}</td><td>${esc(s.delivery_mode)}</td></tr>`).join('') || '<tr><td colspan="5">No scripts yet.</td></tr>';
  const body = `<main class="dashboard-page"><div class="page-head"><div><span class="mini-label">Scripts</span><h1>Scripts</h1><p>Add protected script entries and track versions.</p></div></div><section class="two-col narrow"><div class="panel"><div class="panel-head"><h2>Add script</h2></div><form method="post" action="/dashboard/scripts" class="stack-form"><label>Project<select name="projectId" required>${options}</select></label><label>Script name<input name="name" required placeholder="premium-loader" /></label><label>Version<input name="version" placeholder="v1.0.0" /></label><button class="btn btn-primary">Add script</button></form></div><div class="panel"><div class="panel-head"><h2>Script list</h2></div><table><thead><tr><th>Name</th><th>Project</th><th>Version</th><th>Status</th><th>Mode</th></tr></thead><tbody>${rows}</tbody></table></div></section></main>`;
  return appLayout({ title: 'Scripts', body, user, flash, current: 'scripts' });
}

function keysPage({ user, projects, scripts, keys, flash, generatedKey }) {
  const projectOptions = projects.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
  const scriptOptions = `<option value="">Any script in project</option>` + scripts.map(s => `<option value="${esc(s.id)}">${esc(s.name)} · ${esc(s.project_name)}</option>`).join('');
  const rows = keys.map(k => `<tr><td><code>${esc(k.key_value)}</code></td><td>${esc(k.label)}</td><td>${esc(k.project_name)}</td><td>${esc(k.script_name || 'Any')}</td><td><span class="status ${k.status}">${esc(k.status)}</span></td><td><form method="post" action="/dashboard/keys/${esc(k.id)}/revoke"><button class="mini-btn">Revoke</button></form></td></tr>`).join('') || '<tr><td colspan="6">No keys yet.</td></tr>';
  const keyBox = generatedKey ? `<div class="generated-key"><span>New key</span><code>${esc(generatedKey)}</code></div>` : '';
  const body = `<main class="dashboard-page"><div class="page-head"><div><span class="mini-label">Keys</span><h1>Access Keys</h1><p>Create keys for buyers, testers, and private members.</p></div></div>${keyBox}<section class="two-col narrow"><div class="panel"><div class="panel-head"><h2>Create key</h2></div><form method="post" action="/dashboard/keys" class="stack-form"><label>Project<select name="projectId" required>${projectOptions}</select></label><label>Script<select name="scriptId">${scriptOptions}</select></label><label>Label<input name="label" placeholder="Demo buyer" required /></label><label>Expires at<input name="expiresAt" type="date" /></label><button class="btn btn-primary">Generate key</button></form></div><div class="panel"><div class="panel-head"><h2>Key list</h2></div><table><thead><tr><th>Key</th><th>Label</th><th>Project</th><th>Script</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table></div></section></main>`;
  return appLayout({ title: 'Keys', body, user, flash, current: 'keys' });
}

function placeholderAppPage({ user, flash, current, title, text }) {
  const body = `<main class="dashboard-page"><div class="page-head"><div><span class="mini-label">${esc(title)}</span><h1>${esc(title)}</h1><p>${esc(text)}</p></div></div><section class="panel empty-state"><h2>Module ready</h2><p>This page is wired into the protected dashboard shell. Add backend routes here when you need deeper behavior.</p></section></main>`;
  return appLayout({ title, body, user, flash, current });
}

function logsPage({ user, logs, flash }) {
  const rows = logs.map(l => `<tr><td>${esc(l.created_at)}</td><td>${esc(l.action)}</td><td>${esc(l.target_type)}</td><td>${esc(l.message)}</td></tr>`).join('') || '<tr><td colspan="4">No logs.</td></tr>';
  const body = `<main class="dashboard-page"><div class="page-head"><div><span class="mini-label">Audit</span><h1>Audit Logs</h1><p>Important account and dashboard actions.</p></div></div><section class="panel"><table><thead><tr><th>Time</th><th>Action</th><th>Target</th><th>Message</th></tr></thead><tbody>${rows}</tbody></table></section></main>`;
  return appLayout({ title: 'Audit Logs', body, user, flash, current: 'logs' });
}

module.exports = {
  landing,
  authPage,
  featurePage,
  pricingPage,
  docsPage,
  dashboardHome,
  projectsPage,
  scriptsPage,
  keysPage,
  placeholderAppPage,
  logsPage
};
