const express = require('express');
const { createUser, verifyLogin } = require('../db');
const { requireGuest, flash, asyncRoute } = require('../middleware');
const views = require('../views');
const router = express.Router();

router.get('/login', requireGuest, (req, res) => {
  res.send(views.authPage({ type: 'login', flash: res.locals.flash }));
});

router.post('/login', requireGuest, asyncRoute(async (req, res) => {
  try {
    const remember = req.body.remember === '1';
    if (remember) req.session.cookie.maxAge = 1000 * 60 * 60 * 24 * 7;
    const user = await verifyLogin(req.body.email, req.body.password, req.ip);
    req.session.userId = user.id;
    flash(req, 'ok', 'Signed in.');
    res.redirect('/dashboard');
  } catch (err) {
    flash(req, 'error', err.message);
    res.redirect('/login');
  }
}));

router.get('/signup', requireGuest, (req, res) => {
  res.send(views.authPage({ type: 'signup', flash: res.locals.flash }));
});

router.post('/signup', requireGuest, asyncRoute(async (req, res) => {
  try {
    const remember = req.body.remember === '1';
    if (remember) req.session.cookie.maxAge = 1000 * 60 * 60 * 24 * 7;
    const user = await createUser({
      email: req.body.email,
      username: req.body.username,
      password: req.body.password
    });
    req.session.userId = user.id;
    flash(req, 'ok', 'Account created.');
    res.redirect('/dashboard');
  } catch (err) {
    flash(req, 'error', err.message);
    res.redirect('/signup');
  }
}));

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

module.exports = router;
