const express = require('express');
const {
  getOverview,
  getProjects,
  createProject,
  getScripts,
  createScript,
  getKeys,
  createKey,
  revokeKey,
  getLogs
} = require('../db');
const { requireAuth, flash, asyncRoute } = require('../middleware');
const views = require('../views');
const router = express.Router();

router.use(requireAuth);

router.get('/dashboard', asyncRoute(async (req, res) => {
  const [overview, projects, logs] = await Promise.all([
    getOverview(req.user.id),
    getProjects(req.user.id),
    getLogs(req.user.id, 8)
  ]);
  res.send(views.dashboardHome({
    user: req.user,
    flash: res.locals.flash,
    overview,
    projects,
    logs
  }));
}));

router.get('/dashboard/projects', asyncRoute(async (req, res) => {
  res.send(views.projectsPage({ user: req.user, flash: res.locals.flash, projects: await getProjects(req.user.id) }));
}));

router.post('/dashboard/projects', asyncRoute(async (req, res) => {
  try {
    if (!req.body.name || req.body.name.trim().length < 2) throw new Error('Project name is too short.');
    await createProject(req.user.id, req.body.name);
    flash(req, 'ok', 'Project created.');
  } catch (err) {
    flash(req, 'error', err.message);
  }
  res.redirect('/dashboard/projects');
}));

router.get('/dashboard/scripts', asyncRoute(async (req, res) => {
  const [projects, scripts] = await Promise.all([
    getProjects(req.user.id),
    getScripts(req.user.id)
  ]);
  res.send(views.scriptsPage({
    user: req.user,
    flash: res.locals.flash,
    projects,
    scripts
  }));
}));

router.post('/dashboard/scripts', asyncRoute(async (req, res) => {
  try {
    if (!req.body.name || req.body.name.trim().length < 2) throw new Error('Script name is too short.');
    await createScript(req.user.id, {
      projectId: req.body.projectId,
      name: req.body.name,
      version: req.body.version || 'v1.0.0'
    });
    flash(req, 'ok', 'Script added.');
  } catch (err) {
    flash(req, 'error', err.message);
  }
  res.redirect('/dashboard/scripts');
}));

router.get('/dashboard/keys', asyncRoute(async (req, res) => {
  const [projects, scripts, keys] = await Promise.all([
    getProjects(req.user.id),
    getScripts(req.user.id),
    getKeys(req.user.id)
  ]);
  res.send(views.keysPage({
    user: req.user,
    flash: res.locals.flash,
    projects,
    scripts,
    keys,
    generatedKey: req.session.generatedKey || null
  }));
  delete req.session.generatedKey;
}));

router.post('/dashboard/keys', asyncRoute(async (req, res) => {
  try {
    const keyValue = await createKey(req.user.id, {
      projectId: req.body.projectId,
      scriptId: req.body.scriptId || null,
      label: req.body.label,
      expiresAt: req.body.expiresAt || null
    });
    req.session.generatedKey = keyValue;
    flash(req, 'ok', 'Key generated. Copy it now.');
  } catch (err) {
    flash(req, 'error', err.message);
  }
  res.redirect('/dashboard/keys');
}));

router.post('/dashboard/keys/:id/revoke', asyncRoute(async (req, res) => {
  try {
    await revokeKey(req.user.id, req.params.id);
    flash(req, 'ok', 'Key revoked.');
  } catch (err) {
    flash(req, 'error', err.message);
  }
  res.redirect('/dashboard/keys');
}));

router.get('/dashboard/resets', (req, res) => {
  res.send(views.placeholderAppPage({
    user: req.user,
    flash: res.locals.flash,
    current: 'resets',
    title: 'HWID Resets',
    text: 'Review requested device resets and approve only the ones that make sense.'
  }));
});

router.get('/dashboard/logs', asyncRoute(async (req, res) => {
  res.send(views.logsPage({ user: req.user, flash: res.locals.flash, logs: await getLogs(req.user.id, 100) }));
}));

router.get('/dashboard/settings', (req, res) => {
  res.send(views.placeholderAppPage({
    user: req.user,
    flash: res.locals.flash,
    current: 'settings',
    title: 'Settings',
    text: 'Account, billing, team members, Discord integrations, and API tokens belong here.'
  }));
});

module.exports = router;
