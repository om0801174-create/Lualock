const express = require('express');
const views = require('../views');
const router = express.Router();

router.get('/', (req, res) => res.send(views.landing({ flash: res.locals.flash, user: req.user })));
router.get('/features', (req, res) => res.send(views.featurePage({ flash: res.locals.flash, user: req.user })));
router.get('/pricing', (req, res) => res.send(views.pricingPage({ flash: res.locals.flash, user: req.user })));
router.get('/docs', (req, res) => res.send(views.docsPage({ flash: res.locals.flash, user: req.user })));

module.exports = router;
