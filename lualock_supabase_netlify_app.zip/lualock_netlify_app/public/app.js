const reveals = document.querySelectorAll('.reveal');
const show = () => {
  reveals.forEach((el) => {
    const box = el.getBoundingClientRect();
    if (box.top < window.innerHeight - 60) el.classList.add('visible');
  });
};
show();
window.addEventListener('scroll', show, { passive: true });
setTimeout(() => document.querySelectorAll('.toast').forEach(t => t.style.display = 'none'), 5000);
